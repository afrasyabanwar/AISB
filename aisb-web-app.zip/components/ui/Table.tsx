
import React from 'react';

const Table: React.FC<{ children: React.ReactNode }> & {
    Head: React.FC<{ children: React.ReactNode }>;
    Body: React.FC<{ children: React.ReactNode }>;
    Row: React.FC<{ children: React.ReactNode }>;
    Header: React.FC<{ children: React.ReactNode }>;
    Cell: React.FC<{ children: React.ReactNode, className?: string }>;
} = ({ children }) => {
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-left">{children}</table>
        </div>
    );
};

const TableHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <thead className="bg-gray-800">{children}</thead>
);

const TableBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <tbody className="divide-y divide-gray-700">{children}</tbody>
);

const TableRow: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <tr className="hover:bg-gray-800/50 transition-colors">{children}</tr>
);

const TableHeader: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <th className="p-4 text-sm font-semibold text-textSecondary uppercase tracking-wider">{children}</th>
);

const TableCell: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className }) => (
    <td className={`p-4 align-middle ${className}`}>{children}</td>
);


Table.Head = TableHead;
Table.Body = TableBody;
Table.Row = TableRow;
Table.Header = TableHeader;
Table.Cell = TableCell;

export default Table;
