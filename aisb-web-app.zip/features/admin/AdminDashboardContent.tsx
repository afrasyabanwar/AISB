
import React from 'react';
import Card from '../../components/ui/Card';
import { courses, leaderboardData } from '../../data/mockData';

const StatCard: React.FC<{ title: string, value: string | number, icon: string }> = ({ title, value, icon }) => (
    <Card className="flex items-center space-x-4">
        <div className="text-3xl">{icon}</div>
        <div>
            <p className="text-textSecondary">{title}</p>
            <p className="text-2xl font-bold text-textPrimary">{value}</p>
        </div>
    </Card>
)

const AdminDashboardContent: React.FC = () => {
    // Assuming 'instructors' can be derived or will come from data
    const totalInstructors = new Set(courses.map(c => c.instructor)).size;
    const totalUsers = leaderboardData.length;
    const totalCourses = courses.length;

    return (
        <>
            <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Total Users" value={totalUsers} icon="👥" />
                <StatCard title="Total Courses" value={totalCourses} icon="📚" />
                <StatCard title="Total Instructors" value={totalInstructors} icon="🧑‍🏫" />
            </div>
            {/* More dashboard components can be added here, like recent activity, charts, etc. */}
        </>
    );
};

export default AdminDashboardContent;
