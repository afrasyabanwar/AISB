
import React, { useState } from 'react';
import { courses as initialCourses } from '../../data/mockData';
import { Course, CourseModule } from '../../types';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Table from '../../components/ui/Table';
import EditIcon from '../../components/icons/EditIcon';
import DeleteIcon from '../../components/icons/DeleteIcon';
import EditCourseModal from './EditCourseModal';

const CourseManagementPage: React.FC = () => {
    const [courses, setCourses] = useState<Course[]>(initialCourses);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCourse, setEditingCourse] = useState<Course | null>(null);

    const handleOpenModal = (course: Course | null = null) => {
        setEditingCourse(course);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingCourse(null);
    };

    const handleSaveCourse = (savedCourse: Course) => {
        if (editingCourse) {
            // Update existing course
            setCourses(courses.map(c => c.id === savedCourse.id ? savedCourse : c));
        } else {
            // Add new course
            const newCourse = { ...savedCourse, id: `c-${Date.now()}` };
            setCourses([...courses, newCourse]);
        }
        handleCloseModal();
    };

    const handleDeleteCourse = (courseId: string) => {
        if (window.confirm("Are you sure you want to delete this course?")) {
            setCourses(courses.filter(c => c.id !== courseId));
        }
    };

    return (
        <>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Course Management</h1>
                <Button onClick={() => handleOpenModal()}>+ Add New Course</Button>
            </div>
            <Card className="overflow-x-auto">
                <Table>
                    <Table.Head>
                        <Table.Row>
                            <Table.Header>Title</Table.Header>
                            <Table.Header>Instructor</Table.Header>
                            <Table.Header>Modules</Table.Header>
                            <Table.Header>Progress (%)</Table.Header>
                            <Table.Header>Actions</Table.Header>
                        </Table.Row>
                    </Table.Head>
                    <Table.Body>
                        {courses.map(course => (
                            <Table.Row key={course.id}>
                                <Table.Cell className="font-medium">{course.title}</Table.Cell>
                                <Table.Cell>{course.instructor}</Table.Cell>
                                <Table.Cell>{course.modules?.length || 0}</Table.Cell>
                                <Table.Cell>{course.progress}</Table.Cell>
                                <Table.Cell>
                                    <div className="flex space-x-2">
                                        <Button variant="ghost" className="p-2" onClick={() => handleOpenModal(course)} aria-label="Edit course">
                                            <EditIcon className="w-5 h-5" />
                                        </Button>
                                        <Button variant="ghost" className="p-2" onClick={() => handleDeleteCourse(course.id)} aria-label="Delete course">
                                            <DeleteIcon className="w-5 h-5 text-red-500" />
                                        </Button>
                                    </div>
                                </Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </Card>

            <EditCourseModal 
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveCourse}
                course={editingCourse}
            />
        </>
    );
};

export default CourseManagementPage;
