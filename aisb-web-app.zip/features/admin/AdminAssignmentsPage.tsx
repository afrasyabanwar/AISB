
import React, { useState } from 'react';
import { assignments as initialAssignments, courses } from '../../data/mockData';
import { Assignment } from '../../types';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Table from '../../components/ui/Table';
import EditIcon from '../../components/icons/EditIcon';
import DeleteIcon from '../../components/icons/DeleteIcon';
import EditAssignmentModal from './EditAssignmentModal';

const AdminAssignmentsPage: React.FC = () => {
    const [assignments, setAssignments] = useState<Assignment[]>(initialAssignments);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);

    const handleOpenModal = (assignment: Assignment | null = null) => {
        setEditingAssignment(assignment);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingAssignment(null);
    };

    const handleSaveAssignment = (savedAssignment: Assignment) => {
        if (editingAssignment) {
            setAssignments(assignments.map(a => a.id === savedAssignment.id ? savedAssignment : a));
        } else {
            const newAssignment = { ...savedAssignment, id: `assign-${Date.now()}` };
            setAssignments([...assignments, newAssignment]);
        }
        handleCloseModal();
    };

    const handleDeleteAssignment = (assignmentId: string) => {
        if (window.confirm("Are you sure you want to delete this assignment?")) {
            setAssignments(assignments.filter(a => a.id !== assignmentId));
        }
    };

    const getCourseTitle = (courseId: string) => {
        return courses.find(c => c.id === courseId)?.title || 'Unknown Course';
    };

    const getStatusChip = (status: Assignment['status']) => {
        const colors = {
            Published: 'bg-green-500/20 text-green-300',
            Draft: 'bg-yellow-500/20 text-yellow-300',
            Archived: 'bg-gray-500/20 text-gray-300',
        };
        return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colors[status]}`}>{status}</span>;
    }

    return (
        <>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Assignment Management</h1>
                <Button onClick={() => handleOpenModal()}>+ Add New Assignment</Button>
            </div>
            <Card className="overflow-x-auto">
                <Table>
                    <Table.Head>
                        <Table.Row>
                            <Table.Header>Title</Table.Header>
                            <Table.Header>Course</Table.Header>
                            <Table.Header>Due Date</Table.Header>
                            <Table.Header>Status</Table.Header>
                            <Table.Header>Actions</Table.Header>
                        </Table.Row>
                    </Table.Head>
                    <Table.Body>
                        {assignments.map(assignment => (
                            <Table.Row key={assignment.id}>
                                <Table.Cell className="font-medium">{assignment.title}</Table.Cell>
                                <Table.Cell>{getCourseTitle(assignment.courseId)}</Table.Cell>
                                <Table.Cell>{assignment.dueDate}</Table.Cell>
                                <Table.Cell>{getStatusChip(assignment.status)}</Table.Cell>
                                <Table.Cell>
                                    <div className="flex space-x-2">
                                        <Button variant="ghost" className="p-2" onClick={() => handleOpenModal(assignment)} aria-label="Edit assignment">
                                            <EditIcon className="w-5 h-5" />
                                        </Button>
                                        <Button variant="ghost" className="p-2" onClick={() => handleDeleteAssignment(assignment.id)} aria-label="Delete assignment">
                                            <DeleteIcon className="w-5 h-5 text-red-500" />
                                        </Button>
                                    </div>
                                </Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </Card>
            
            <EditAssignmentModal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveAssignment}
                assignment={editingAssignment}
            />
        </>
    );
};

export default AdminAssignmentsPage;
