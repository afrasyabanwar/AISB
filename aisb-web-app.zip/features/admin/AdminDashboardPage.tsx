
import React, { useState } from 'react';
import Header from '../dashboard/Header';
import AdminSidebar from './AdminSidebar';
import CourseManagementPage from './CourseManagementPage';
import UserManagementPage from './UserManagementPage';
import AdminAssignmentsPage from './AdminAssignmentsPage';
import AdminDashboardContent from './AdminDashboardContent';
import AdminSettingsPage from './AdminSettingsPage';
import { User } from '../../types';

interface AdminDashboardPageProps {
  onLogout: () => void;
  onSwitchToStudent: () => void;
  user: User;
}

export type AdminPage = 'Dashboard' | 'Course Management' | 'User Management' | 'Assignments' | 'Settings';


const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onLogout, onSwitchToStudent, user }) => {
    const [activePage, setActivePage] = useState<AdminPage>('Dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    const handleNavigate = (page: AdminPage) => {
        setActivePage(page);
        setIsSidebarOpen(false);
    };

    const renderContent = () => {
        switch(activePage) {
            case 'Dashboard':
                return <AdminDashboardContent />;
            case 'Course Management':
                return <CourseManagementPage />;
            case 'User Management':
                return <UserManagementPage />;
            case 'Assignments':
                return <AdminAssignmentsPage />;
            case 'Settings':
                return <AdminSettingsPage />;
            default:
                return <AdminDashboardContent />;
        }
    }

    return (
        <div className="flex h-screen bg-background">
            <AdminSidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} activePage={activePage} onNavigate={handleNavigate} />
            <div className="flex-1 flex flex-col overflow-hidden relative">
                {isSidebarOpen && <div className="absolute inset-0 bg-black bg-opacity-50 z-20 md:hidden" onClick={() => setIsSidebarOpen(false)}></div>}
                <Header 
                    onLogout={onLogout}
                    onNavigate={() => {}} // Admin header doesn't use main navigation
                    pageTitle={activePage}
                    onSwitchRole={onSwitchToStudent}
                    role="admin"
                    user={user}
                    onToggleSidebar={() => setIsSidebarOpen(true)}
                />
                 <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-4 md:p-8">
                    {renderContent()}
                </main>
            </div>
        </div>
    );
};

export default AdminDashboardPage;