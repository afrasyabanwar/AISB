
import React, { useState } from 'react';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import ToggleSwitch from '../../components/ui/ToggleSwitch';

const AdminSettingsPage: React.FC = () => {
    const [siteName, setSiteName] = useState('AISB Web App');
    const [notifications, setNotifications] = useState({
        newUser: true,
        courseCompletion: true,
        newAssignment: false,
    });

    const handleToggle = (key: keyof typeof notifications) => {
        setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
    }

    return (
        <>
            <h1 className="text-3xl font-bold mb-6">Admin Settings</h1>
            <div className="max-w-4xl mx-auto space-y-8">
                {/* General Settings */}
                <Card>
                    <h2 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">General Settings</h2>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="siteName" className="block text-sm font-medium text-textSecondary mb-1">Site Name</label>
                            <Input id="siteName" value={siteName} onChange={(e) => setSiteName(e.target.value)} />
                        </div>
                    </div>
                </Card>

                {/* Notification Settings */}
                <Card>
                    <h2 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Notification Settings</h2>
                    <p className="text-sm text-textSecondary mb-4">Configure email notifications for important events.</p>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <div>
                                <h3 className="font-medium">New User Signups</h3>
                                <p className="text-sm text-textSecondary">Receive an email when a new student or instructor registers.</p>
                            </div>
                            <ToggleSwitch checked={notifications.newUser} onChange={() => handleToggle('newUser')} />
                        </div>
                        <div className="flex justify-between items-center">
                            <div>
                                <h3 className="font-medium">Course Completions</h3>
                                <p className="text-sm text-textSecondary">Get notified when a student completes a course.</p>
                            </div>
                            <ToggleSwitch checked={notifications.courseCompletion} onChange={() => handleToggle('courseCompletion')} />
                        </div>
                         <div className="flex justify-between items-center">
                            <div>
                                <h3 className="font-medium">New Assignment Submissions</h3>
                                <p className="text-sm text-textSecondary">Receive alerts for new assignment submissions.</p>
                            </div>
                            <ToggleSwitch checked={notifications.newAssignment} onChange={() => handleToggle('newAssignment')} />
                        </div>
                    </div>
                </Card>

                {/* Security Settings */}
                <Card>
                     <h2 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Security & API</h2>
                     <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <div>
                                <h3 className="font-medium">Change Admin Password</h3>
                                <p className="text-sm text-textSecondary">Update your administrator account password.</p>
                            </div>
                            <Button variant="secondary">Change Password</Button>
                        </div>
                         <div className="flex justify-between items-center">
                            <div>
                                <h3 className="font-medium">API Key</h3>
                                <p className="text-sm text-textSecondary">Used for integrations with third-party services.</p>
                            </div>
                             <div className="flex items-center space-x-2">
                                <Input type="text" readOnly value="sb-********************-key" className="font-mono text-sm" />
                                <Button variant="secondary">Copy</Button>
                             </div>
                        </div>
                    </div>
                </Card>
                
                 <div className="flex justify-end pt-4">
                    <Button>Save All Settings</Button>
                </div>
            </div>
        </>
    );
};

export default AdminSettingsPage;