
import React, { useState, useEffect } from 'react';
import Modal from '../../components/ui/Modal';
import { Assignment } from '../../types';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { courses } from '../../data/mockData';

interface EditAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (assignment: Assignment) => void;
  assignment: Assignment | null;
}

const emptyAssignment: Omit<Assignment, 'id'> = {
  title: '',
  courseId: courses[0]?.id || '',
  dueDate: '',
  status: 'Draft',
};

const EditAssignmentModal: React.FC<EditAssignmentModalProps> = ({ isOpen, onClose, onSave, assignment }) => {
  const [formData, setFormData] = useState<Omit<Assignment, 'id'> & { id?: string }>(emptyAssignment);

  useEffect(() => {
    if (assignment) {
      setFormData(assignment);
    } else {
      setFormData(emptyAssignment);
    }
  }, [assignment, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.courseId) {
        alert('Please select a course.');
        return;
    }
    onSave(formData as Assignment);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={assignment ? 'Edit Assignment' : 'Add New Assignment'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-textSecondary">Assignment Title</label>
          <Input id="title" name="title" value={formData.title} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="courseId" className="block text-sm font-medium text-textSecondary">Course</label>
          <select 
            id="courseId" 
            name="courseId" 
            value={formData.courseId} 
            onChange={handleChange}
            className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
          >
            <option value="" disabled>Select a course</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>{course.title}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="dueDate" className="block text-sm font-medium text-textSecondary">Due Date</label>
          <Input id="dueDate" name="dueDate" type="date" value={formData.dueDate} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-textSecondary">Status</label>
           <select 
            id="status" 
            name="status" 
            value={formData.status} 
            onChange={handleChange}
            className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
          >
            <option>Draft</option>
            <option>Published</option>
            <option>Archived</option>
          </select>
        </div>
        <div className="pt-6 flex justify-end space-x-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit">Save Assignment</Button>
        </div>
      </form>
    </Modal>
  );
};

export default EditAssignmentModal;