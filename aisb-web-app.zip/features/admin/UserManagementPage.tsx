
import React, { useState } from 'react';
import { users as initialUsers } from '../../data/mockData';
import { User } from '../../types';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Table from '../../components/ui/Table';
import EditIcon from '../../components/icons/EditIcon';
import DeleteIcon from '../../components/icons/DeleteIcon';
import EditUserModal from './EditUserModal';

const UserManagementPage: React.FC = () => {
    const [users, setUsers] = useState<User[]>(initialUsers);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);

    const handleOpenModal = (user: User | null = null) => {
        setEditingUser(user);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingUser(null);
    };

    const handleSaveUser = (savedUser: User) => {
        if (editingUser) {
            setUsers(users.map(u => u.id === savedUser.id ? savedUser : u));
        } else {
            const newUser = { ...savedUser, id: `user-${Date.now()}` };
            setUsers([...users, newUser]);
        }
        handleCloseModal();
    };

    const handleDeleteUser = (userId: string) => {
        if (window.confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
            setUsers(users.filter(u => u.id !== userId));
        }
    };

    const getRoleChip = (role: User['role']) => {
        const colors = {
            Admin: 'bg-red-500/20 text-red-300',
            Instructor: 'bg-blue-500/20 text-blue-300',
            Student: 'bg-green-500/20 text-green-300',
        };
        return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colors[role]}`}>{role}</span>;
    };

    return (
        <>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">User Management</h1>
                <Button onClick={() => handleOpenModal()}>+ Add New User</Button>
            </div>
            <Card className="overflow-x-auto">
                <Table>
                    <Table.Head>
                        <Table.Row>
                            <Table.Header>Name</Table.Header>
                            <Table.Header>Email</Table.Header>
                            <Table.Header>Role</Table.Header>
                            <Table.Header>Actions</Table.Header>
                        </Table.Row>
                    </Table.Head>
                    <Table.Body>
                        {users.map(user => (
                            <Table.Row key={user.id}>
                                <Table.Cell className="font-medium flex items-center space-x-3">
                                    <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full" />
                                    <span>{user.name}</span>
                                </Table.Cell>
                                <Table.Cell>{user.email}</Table.Cell>
                                <Table.Cell>{getRoleChip(user.role)}</Table.Cell>
                                <Table.Cell>
                                    <div className="flex space-x-2">
                                        <Button variant="ghost" className="p-2" onClick={() => handleOpenModal(user)} aria-label="Edit user">
                                            <EditIcon className="w-5 h-5" />
                                        </Button>
                                        <Button variant="ghost" className="p-2" onClick={() => handleDeleteUser(user.id)} aria-label="Delete user">
                                            <DeleteIcon className="w-5 h-5 text-red-500" />
                                        </Button>
                                    </div>
                                </Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </Card>

            <EditUserModal 
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveUser}
                user={editingUser}
            />
        </>
    );
};

export default UserManagementPage;
