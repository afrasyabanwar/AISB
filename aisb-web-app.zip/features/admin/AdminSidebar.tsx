
import React from 'react';
import { AdminPage } from './AdminDashboardPage';
import UsersIcon from '../../components/icons/UsersIcon';
import SettingsIcon from '../../components/icons/SettingsIcon';
import CloseIcon from '../../components/icons/CloseIcon';

// Dummy icons from student sidebar, can be replaced
const DashboardIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const CoursesIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 14l9-5-9-5-9 5 9 5z" /><path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-5.998 12.078 12.078 0 01.665-6.479L12 14z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0v6" /></svg>;
const AssignmentsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>;


interface NavItemProps {
    icon: React.ReactNode;
    label: string;
    active?: boolean;
    onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, active = false, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors w-full text-left ${active ? 'bg-primary text-white' : 'text-textSecondary hover:bg-gray-700 hover:text-white'}`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

interface SidebarProps {
    isOpen: boolean;
    onClose: () => void;
    activePage: AdminPage;
    onNavigate: (page: AdminPage) => void;
}

const navItems: { label: AdminPage, icon: JSX.Element }[] = [
    { label: 'Dashboard', icon: <DashboardIcon /> },
    { label: 'Course Management', icon: <CoursesIcon /> },
    { label: 'User Management', icon: <UsersIcon /> },
    { label: 'Assignments', icon: <AssignmentsIcon /> },
    { label: 'Settings', icon: <SettingsIcon /> },
];


const AdminSidebar: React.FC<SidebarProps> = ({ isOpen, onClose, activePage, onNavigate }) => {
  return (
    <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-surface p-4 flex flex-col shrink-0 transform md:relative md:translate-x-0 transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex justify-between items-center mb-2">
        <div className="text-2xl font-bold text-white">AISB</div>
         <button onClick={onClose} className="md:hidden text-textSecondary" aria-label="Close sidebar">
            <CloseIcon className="w-6 h-6" />
        </button>
      </div>
      <div className="text-sm font-semibold text-secondary mb-8">Admin Panel</div>
      <nav className="flex flex-col space-y-2">
        {navItems.map(item => (
            <NavItem 
                key={item.label}
                icon={item.icon}
                label={item.label}
                active={activePage === item.label}
                onClick={() => onNavigate(item.label)}
            />
        ))}
      </nav>
    </aside>
  );
};

export default AdminSidebar;
