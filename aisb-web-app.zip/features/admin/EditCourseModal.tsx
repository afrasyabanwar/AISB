
import React, { useState, useEffect } from 'react';
import Modal from '../../components/ui/Modal';
import { Course, CourseModule } from '../../types';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import DeleteIcon from '../../components/icons/DeleteIcon';

interface EditCourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (course: Course) => void;
  course: Course | null;
}

const emptyCourse: Omit<Course, 'id'> = {
  title: '',
  description: '',
  instructor: '',
  progress: 0,
  modules: []
};

const EditCourseModal: React.FC<EditCourseModalProps> = ({ isOpen, onClose, onSave, course }) => {
  const [formData, setFormData] = useState<Omit<Course, 'id'> & { id?: string }>(emptyCourse);
  const [newModuleTitle, setNewModuleTitle] = useState('');

  useEffect(() => {
    if (course) {
      setFormData({ ...course, modules: course.modules || [] });
    } else {
      setFormData(emptyCourse);
    }
  }, [course, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, progress: parseInt(e.target.value, 10) }));
  };

  const handleModuleChange = (index: number, field: keyof CourseModule, value: string) => {
    if (!formData.modules) return;
    const newModules = [...formData.modules];
    // @ts-ignore
    newModules[index][field] = value;
    setFormData(prev => ({ ...prev, modules: newModules }));
  };

  const handleAddModule = () => {
    if (newModuleTitle.trim()) {
      const newModule: CourseModule = {
        id: `m-${Date.now()}`,
        title: newModuleTitle.trim(),
        status: 'Not Started',
      };
      setFormData(prev => ({ ...prev, modules: [...(prev.modules || []), newModule] }));
      setNewModuleTitle('');
    }
  };

  const handleRemoveModule = (moduleId: string) => {
    setFormData(prev => ({ ...prev, modules: (prev.modules || []).filter(m => m.id !== moduleId) }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Course);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={course ? 'Edit Course' : 'Add New Course'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-textSecondary">Title</label>
          <Input id="title" name="title" value={formData.title} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="instructor" className="block text-sm font-medium text-textSecondary">Instructor</label>
          <Input id="instructor" name="instructor" value={formData.instructor} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-textSecondary">Description</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={3}
            className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
          />
        </div>
        <div>
          <label htmlFor="progress" className="block text-sm font-medium text-textSecondary">Progress: {formData.progress}%</label>
          <input
            id="progress"
            type="range"
            min="0"
            max="100"
            value={formData.progress}
            onChange={handleProgressChange}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>
        
        <div className="pt-4">
            <h3 className="text-lg font-semibold mb-2 text-textPrimary">Modules</h3>
             <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                {(formData.modules || []).map((module, index) => (
                    <div key={module.id} className="flex items-center space-x-2">
                       <Input value={module.title} onChange={e => handleModuleChange(index, 'title', e.target.value)} className="flex-1" />
                       <select value={module.status} onChange={e => handleModuleChange(index, 'status', e.target.value)} className="px-3 py-2 bg-background border border-gray-600 rounded-md">
                           <option>Not Started</option>
                           <option>In Progress</option>
                           <option>Completed</option>
                       </select>
                       <Button type="button" variant="ghost" onClick={() => handleRemoveModule(module.id)} className="p-2">
                           <DeleteIcon className="w-5 h-5 text-red-500"/>
                       </Button>
                    </div>
                ))}
             </div>
             <div className="flex items-center space-x-2 mt-3">
                <Input placeholder="New module title..." value={newModuleTitle} onChange={e => setNewModuleTitle(e.target.value)} className="flex-1" />
                <Button type="button" variant="secondary" onClick={handleAddModule}>Add Module</Button>
             </div>
        </div>
        
        <div className="pt-6 flex justify-end space-x-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit">Save Course</Button>
        </div>
      </form>
    </Modal>
  );
};

export default EditCourseModal;
