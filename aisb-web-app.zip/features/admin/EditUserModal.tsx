
import React, { useState, useEffect } from 'react';
import Modal from '../../components/ui/Modal';
import { User } from '../../types';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';

interface EditUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (user: User) => void;
  user: User | null;
}

const emptyUser: Omit<User, 'id' | 'avatarUrl'> = {
  name: '',
  email: '',
  role: 'Student',
};

const EditUserModal: React.FC<EditUserModalProps> = ({ isOpen, onClose, onSave, user }) => {
  const [formData, setFormData] = useState<Omit<User, 'id' | 'avatarUrl'> & { id?: string }>(emptyUser);

  useEffect(() => {
    if (user) {
      setFormData(user);
    } else {
      setFormData(emptyUser);
    }
  }, [user, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
        ...formData,
        avatarUrl: `https://i.pravatar.cc/40?u=${formData.email}`
    } as User);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={user ? 'Edit User' : 'Add New User'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-textSecondary">Full Name</label>
          <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-textSecondary">Email Address</label>
          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="role" className="block text-sm font-medium text-textSecondary">Role</label>
          <select 
            id="role" 
            name="role" 
            value={formData.role} 
            onChange={handleChange}
            className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
          >
            <option>Student</option>
            <option>Instructor</option>
            <option>Admin</option>
          </select>
        </div>
        <div className="pt-6 flex justify-end space-x-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit">Save User</Button>
        </div>
      </form>
    </Modal>
  );
};

export default EditUserModal;