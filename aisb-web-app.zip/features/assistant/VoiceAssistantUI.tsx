
import React, { useState, useRef, useEffect } from 'react';
import { useVoiceAssistant } from '../../hooks/useVoiceAssistant';
import MicrophoneIcon from '../../components/icons/MicrophoneIcon';
import { AssistantMessage } from '../../types';
import Input from '../../components/ui/Input';
import SendIcon from '../../components/icons/SendIcon';
import VolumeUpIcon from '../../components/icons/VolumeUpIcon';
import VolumeOffIcon from '../../components/icons/VolumeOffIcon';

const StatusIndicator: React.FC<{ status: string }> = ({ status }) => {
    let text = 'Ask me anything or try a command.';
    if (status === 'listening') text = 'Listening...';
    if (status === 'processing') text = 'Thinking...';
    if (status === 'speaking') text = 'Speaking...';

    return <p className="text-center text-sm text-textSecondary h-5">{text}</p>;
};

const ChatBubble: React.FC<{ message: AssistantMessage }> = ({ message }) => {
    const isUser = message.speaker === 'user';
    return (
        <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-xl break-words ${isUser ? 'bg-primary text-white' : 'bg-gray-700 text-white'}`}>
                <p>{message.text}</p>
            </div>
        </div>
    );
}

const VoiceAssistantUI: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [inputText, setInputText] = useState('');
    const { status, messages, startListening, isSupported, clearMessages, submitPrompt, isMuted, toggleMute } = useVoiceAssistant();
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);
    
    useEffect(() => {
        if (isOpen) {
            // Focus input when modal opens
            setTimeout(() => inputRef.current?.focus(), 100);
        }
    }, [isOpen]);

    if (!isSupported) {
        return null; // Or show a "not supported" message
    }
    
    const handleToggle = () => {
        setIsOpen(!isOpen);
        if(!isOpen) clearMessages();
    };

    const handleMicClick = () => {
        if (status === 'idle') {
            startListening();
        }
    };
    
    const handleTextSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (inputText.trim() && status === 'idle') {
            submitPrompt(inputText.trim());
            setInputText('');
        }
    }
    
    return (
        <>
            <button
                onClick={handleToggle}
                className="fixed bottom-8 right-8 bg-primary text-white w-16 h-16 rounded-full shadow-lg flex items-center justify-center hover:bg-blue-600 transition-transform transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background focus:ring-primary z-50"
                aria-label="Toggle AI Assistant"
            >
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20"><path d="M7 9a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H9a2 2 0 01-2-2V9z" /><path fillRule="evenodd" d="M5 3a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V5a2 2 0 00-2-2H5zm0 2h10v10H5V5z" clipRule="evenodd" /></svg>
            </button>

            {isOpen && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40" onClick={handleToggle}>
                    <div className="fixed bottom-0 right-0 mb-28 mr-4 md:mr-8 w-11/12 max-w-lg h-[80vh] md:h-2/3 bg-surface rounded-xl shadow-2xl flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()}>
                        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
                           <h2 className="text-xl font-bold text-center flex-1">AISU Assistant</h2>
                           <button onClick={toggleMute} className="p-2 rounded-full hover:bg-gray-600 transition-colors" aria-label={isMuted ? "Unmute" : "Mute"}>
                               {isMuted ? <VolumeOffIcon className="w-5 h-5" /> : <VolumeUpIcon className="w-5 h-5" />}
                           </button>
                        </div>

                        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                            {messages.length === 0 && <p className="text-center text-textSecondary">No messages yet. Start the conversation!</p>}
                            {messages.map((msg, index) => <ChatBubble key={index} message={msg} />)}
                            <div ref={messagesEndRef} />
                        </div>
                        
                         <div className="p-4 border-t border-gray-700 flex flex-col">
                           <StatusIndicator status={status} />
                            <form onSubmit={handleTextSubmit} className="flex items-center space-x-2 mt-2">
                                <Input 
                                    ref={inputRef}
                                    type="text"
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    placeholder={status === 'listening' ? 'Listening...' : 'Type a message...'}
                                    disabled={status !== 'idle'}
                                    className="flex-1"
                                    aria-label="Chat input"
                                />
                                <button
                                    type="button"
                                    onClick={handleMicClick}
                                    disabled={status !== 'idle'}
                                    className={`p-3 rounded-full transition-colors duration-200
                                        ${status === 'listening' ? 'bg-red-500 text-white animate-pulse' : 'bg-secondary text-white'}
                                        ${status !== 'idle' ? 'cursor-not-allowed opacity-50' : 'hover:bg-gray-600'}`}
                                    aria-label="Use microphone"
                                >
                                    <MicrophoneIcon className="w-5 h-5" />
                                </button>
                                <button
                                    type="submit"
                                    disabled={status !== 'idle' || !inputText.trim()}
                                    className="p-3 rounded-full bg-primary text-white transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-600"
                                    aria-label="Send message"
                                >
                                    <SendIcon className="w-5 h-5" />
                                </button>
                            </form>
                        </div>
                    </div>
                 </div>
            )}
        </>
    );
};

export default VoiceAssistantUI;
