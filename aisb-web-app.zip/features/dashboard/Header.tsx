
import React, { useState, useEffect, useRef } from 'react';
import { Page } from './DashboardPage';
import { User } from '../../types';
import MenuIcon from '../../components/icons/MenuIcon';

interface HeaderProps {
  onLogout: () => void;
  onNavigate: (page: Page | 'AdminDashboard') => void;
  pageTitle: string;
  onSwitchRole: () => void;
  role: 'student' | 'admin';
  user?: User; // The actual logged-in user, optional for admin view
  onToggleSidebar?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogout, onNavigate, pageTitle, onSwitchRole, role, user, onToggleSidebar }) => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);
    const isStudentView = role === 'student';

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsDropdownOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const displayName = user ? user.name : 'Admin User';
    const displayAvatar = user ? user.avatarUrl : `https://i.pravatar.cc/40?u=admin`;
    
    // The switch button should only ever be visible if the logged-in user is an admin.
    const showSwitchButton = user?.role === 'Admin';

    return (
        <header className="bg-surface shadow-md p-4 flex justify-between items-center z-10 shrink-0">
            <div className="flex items-center">
                {onToggleSidebar && (
                    <button onClick={onToggleSidebar} className="text-textPrimary mr-4 md:hidden" aria-label="Open sidebar">
                        <MenuIcon className="w-6 h-6" />
                    </button>
                )}
                <h1 className="text-xl font-semibold">{pageTitle}</h1>
            </div>
            <div className="flex items-center space-x-4">
                {showSwitchButton && (
                    <button 
                        onClick={onSwitchRole}
                        className="px-3 py-1.5 text-sm bg-secondary text-white rounded-md hover:bg-orange-500 transition-colors hidden sm:block"
                    >
                        {isStudentView ? 'Admin View' : 'Student View'}
                    </button>
                )}
                <div className="relative" ref={dropdownRef}>
                    <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="flex items-center space-x-2" aria-haspopup="true" aria-expanded={isDropdownOpen}>
                        <img src={displayAvatar} alt="User Avatar" className="w-10 h-10 rounded-full" />
                        <span className="hidden md:block">{displayName}</span>
                    </button>
                    {isDropdownOpen && (
                        <div className="absolute right-0 mt-2 w-48 bg-surface rounded-md shadow-lg py-1 z-50 ring-1 ring-black ring-opacity-5">
                            {isStudentView && (
                                <>
                                    <button onClick={() => { onNavigate('Profile'); setIsDropdownOpen(false); }} className="block w-full text-left px-4 py-2 text-sm text-textPrimary hover:bg-gray-700">Profile</button>
                                    <button onClick={() => { onNavigate('Settings'); setIsDropdownOpen(false); }} className="block w-full text-left px-4 py-2 text-sm text-textPrimary hover:bg-gray-700">Settings</button>
                                    <div className="border-t border-gray-700 my-1"></div>
                                </>
                            )}
                            <button onClick={onLogout} className="block w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-gray-700">
                                Logout
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
};

export default Header;