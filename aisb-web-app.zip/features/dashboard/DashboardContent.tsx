
import React from 'react';
import { courses } from '../../data/mockData';
import CourseCard from '../courses/CourseCard';

interface DashboardContentProps {
    onCourseSelect: (courseId: string) => void;
}

const DashboardContent: React.FC<DashboardContentProps> = ({ onCourseSelect }) => {
  const sampleCourses = courses.slice(0, 3); // Show first 3 courses on dashboard

  return (
    <>
      <h1 className="text-3xl font-bold mb-6">Welcome back, Student!</h1>
      <h2 className="text-2xl font-semibold mb-4 text-textSecondary">Your Courses</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sampleCourses.map(course => 
            <CourseCard 
                key={course.id} 
                course={course} 
                onClick={() => onCourseSelect(course.id)}
            />
          )}
      </div>
    </>
  );
};

export default DashboardContent;
