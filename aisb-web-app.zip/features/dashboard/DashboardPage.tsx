
import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import DashboardContent from './DashboardContent';
import CoursesPage from '../courses/CoursesPage';
import AssignmentsPage from '../assignments/AssignmentsPage';
import ChatPage from '../chat/ChatPage';
import ProfilePage from '../profile/ProfilePage';
import SettingsPage from '../settings/SettingsPage';
import QuizzesPage from '../quizzes/QuizzesPage';
import LeaderboardPage from '../leaderboard/LeaderboardPage';
import TimelinePage from '../timeline/TimelinePage';
import eventBus from '../../services/eventBus';
import { User } from '../../types';

interface DashboardPageProps {
  onLogout: () => void;
  onSwitchToAdmin: () => void;
  user: User;
}

export type Page = 'Dashboard' | 'Courses' | 'Quizzes' | 'Assignments' | 'Leaderboard' | 'Chat' | 'Timeline' | 'Profile' | 'Settings';

const DashboardPage: React.FC<DashboardPageProps> = ({ onLogout, onSwitchToAdmin, user }) => {
  const [activePage, setActivePage] = useState<Page>('Dashboard');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    const handleNavigate = (page: Page) => {
      // Ensure the received page is a valid Page type
      const validPages: Page[] = ['Dashboard', 'Courses', 'Quizzes', 'Assignments', 'Leaderboard', 'Chat', 'Timeline', 'Profile', 'Settings'];
      if (validPages.includes(page)) {
        setActivePage(page);
        setIsSidebarOpen(false); // Close sidebar on navigation
      }
    };

    eventBus.on('navigate', handleNavigate);

    return () => {
      eventBus.remove('navigate', handleNavigate);
    };
  }, []);

  const handleNavigate = (page: Page) => {
    setActivePage(page);
    setSelectedCourseId(null); // Clear course selection when changing main pages
    setIsSidebarOpen(false); // Close sidebar on navigation
  };
  
  const handleCourseSelect = (courseId: string) => {
      setActivePage('Courses');
      setSelectedCourseId(courseId);
  };

  const renderContent = () => {
    switch (activePage) {
      case 'Dashboard':
        return <DashboardContent onCourseSelect={handleCourseSelect} />;
      case 'Courses':
        return <CoursesPage selectedCourseId={selectedCourseId} onCourseSelect={handleCourseSelect} onClearSelection={() => setSelectedCourseId(null)} />;
      case 'Quizzes':
        return <QuizzesPage />;
      case 'Assignments':
        return <AssignmentsPage />;
      case 'Leaderboard':
        return <LeaderboardPage />;
      case 'Chat':
        return <ChatPage />;
      case 'Timeline':
        return <TimelinePage />;
      case 'Profile':
        return <ProfilePage />;
      case 'Settings':
        return <SettingsPage />;
      default:
        return <DashboardContent onCourseSelect={handleCourseSelect} />;
    }
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} activePage={activePage} onNavigate={handleNavigate} />
      <div className="flex-1 flex flex-col overflow-hidden relative">
         {isSidebarOpen && <div className="absolute inset-0 bg-black bg-opacity-50 z-20 md:hidden" onClick={() => setIsSidebarOpen(false)}></div>}
        <Header 
            onLogout={onLogout} 
            onNavigate={handleNavigate} 
            pageTitle={activePage} 
            onSwitchRole={onSwitchToAdmin}
            role="student"
            user={user}
            onToggleSidebar={() => setIsSidebarOpen(true)}
        />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-4 md:p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default DashboardPage;
