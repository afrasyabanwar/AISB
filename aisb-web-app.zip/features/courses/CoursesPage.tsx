
import React from 'react';
import { courses } from '../../data/mockData';
import CourseCard from './CourseCard';
import CourseDetailPage from './CourseDetailPage';

interface CoursesPageProps {
    selectedCourseId: string | null;
    onCourseSelect: (courseId: string) => void;
    onClearSelection: () => void;
}

const CoursesPage: React.FC<CoursesPageProps> = ({ selectedCourseId, onCourseSelect, onClearSelection }) => {
  const selectedCourse = selectedCourseId ? courses.find(c => c.id === selectedCourseId) : null;

  if (selectedCourse) {
    return <CourseDetailPage course={selectedCourse} onBack={onClearSelection} />;
  }
  
  return (
    <>
      <h1 className="text-3xl font-bold mb-6">All Courses</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map(course => (
            <CourseCard 
              key={course.id} 
              course={course} 
              onClick={() => onCourseSelect(course.id)}
            />
          ))}
      </div>
    </>
  );
};

export default CoursesPage;
