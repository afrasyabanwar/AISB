
import React from 'react';
import { Course } from '../../types';
import Card from '../../components/ui/Card';

interface CourseCardProps {
    course: Course;
    onClick: () => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, onClick }) => {
    return (
        <div onClick={onClick} className="h-full cursor-pointer group">
            <Card className="flex flex-col h-full transition-all duration-300 group-hover:shadow-primary/50 group-hover:ring-2 group-hover:ring-primary">
                <h3 className="text-xl font-bold text-primary mb-2">{course.title}</h3>
                <p className="text-textSecondary mb-4 flex-grow">{course.description}</p>
                <p className="text-sm text-textSecondary mb-4">Instructor: {course.instructor}</p>
                <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div className="bg-primary h-2.5 rounded-full" style={{ width: `${course.progress}%` }}></div>
                </div>
                <p className="text-right text-sm mt-1 text-textSecondary">{course.progress}% Complete</p>
            </Card>
        </div>
    );
};

export default CourseCard;
