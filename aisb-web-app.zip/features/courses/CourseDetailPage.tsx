
import React from 'react';
import { Course } from '../../types';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface CourseDetailPageProps {
  course: Course;
  onBack: () => void;
}

const CourseDetailPage: React.FC<CourseDetailPageProps> = ({ course, onBack }) => {
    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Completed': return 'bg-green-500';
            case 'In Progress': return 'bg-yellow-500';
            default: return 'bg-gray-500';
        }
    }

  return (
    <>
      <div className="mb-6">
        <Button variant="secondary" onClick={onBack}>&larr; Back to Courses</Button>
      </div>
      <Card>
        <h1 className="text-3xl font-bold text-primary mb-2">{course.title}</h1>
        <p className="text-lg text-textSecondary mb-4">Taught by {course.instructor}</p>
        <p className="mb-6">{course.description}</p>

        <h2 className="text-2xl font-semibold mb-4 border-t border-gray-700 pt-4">Course Modules</h2>
        {course.modules && course.modules.length > 0 ? (
          <div className="space-y-3">
            {course.modules.map(module => (
              <div key={module.id} className="p-4 bg-gray-900/50 rounded-lg flex justify-between items-center">
                <p className="font-medium">{module.title}</p>
                <span className={`px-3 py-1 text-xs font-semibold rounded-full text-white ${getStatusColor(module.status)}`}>
                    {module.status}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-textSecondary">No modules available for this course yet.</p>
        )}
      </Card>
    </>
  );
};

export default CourseDetailPage;
