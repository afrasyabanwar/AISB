
import React, { useState, useEffect, useMemo } from 'react';
import { Quiz, QuizQuestion } from '../../types';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';

interface QuizTakingPageProps {
  quiz: Quiz;
  onSubmit: (answers: number[]) => void;
}

const QuizTakingPage: React.FC<QuizTakingPageProps> = ({ quiz, onSubmit }) => {
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState<number[]>(() => new Array(quiz.questions.length).fill(-1));
    const [timeLeft, setTimeLeft] = useState(quiz.timeLimit * 60);

    const currentQuestion: QuizQuestion = quiz.questions[currentQuestionIndex];

    useEffect(() => {
        if (timeLeft <= 0) {
            onSubmit(answers);
            return;
        }

        const timer = setInterval(() => {
            setTimeLeft(prevTime => prevTime - 1);
        }, 1000);

        return () => clearInterval(timer);
    }, [timeLeft, answers, onSubmit]);

    const handleAnswerSelect = (optionIndex: number) => {
        const newAnswers = [...answers];
        newAnswers[currentQuestionIndex] = optionIndex;
        setAnswers(newAnswers);
    };

    const handleNext = () => {
        if (currentQuestionIndex < quiz.questions.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
        }
    };

    const handlePrev = () => {
        if (currentQuestionIndex > 0) {
            setCurrentQuestionIndex(prev => prev - 1);
        }
    };

    const handleSubmit = () => {
        if (window.confirm("Are you sure you want to submit your answers?")) {
            onSubmit(answers);
        }
    };

    const formattedTime = useMemo(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }, [timeLeft]);

    return (
        <Card className="max-w-4xl mx-auto">
            <div className="flex justify-between items-center mb-4 pb-4 border-b border-gray-700">
                <h1 className="text-2xl font-bold text-primary">{quiz.title}</h1>
                <div className={`text-xl font-bold ${timeLeft < 60 ? 'text-red-500 animate-pulse' : ''}`}>
                    {formattedTime}
                </div>
            </div>

            <div>
                <p className="text-textSecondary mb-2">Question {currentQuestionIndex + 1} of {quiz.questions.length}</p>
                <h2 className="text-xl font-semibold mb-6">{currentQuestion.questionText}</h2>
                <div className="space-y-3">
                    {currentQuestion.options.map((option, index) => (
                        <label 
                            key={index}
                            className={`block p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                                answers[currentQuestionIndex] === index
                                ? 'bg-primary/30 border-primary'
                                : 'bg-gray-800/50 border-gray-700 hover:border-secondary'
                            }`}
                        >
                            <input
                                type="radio"
                                name={`question-${currentQuestionIndex}`}
                                value={index}
                                checked={answers[currentQuestionIndex] === index}
                                onChange={() => handleAnswerSelect(index)}
                                className="sr-only"
                            />
                            {option}
                        </label>
                    ))}
                </div>
            </div>

            <div className="mt-8 pt-4 border-t border-gray-700 flex justify-between items-center">
                <Button onClick={handlePrev} disabled={currentQuestionIndex === 0}>Previous</Button>
                {currentQuestionIndex === quiz.questions.length - 1 ? (
                    <Button onClick={handleSubmit} variant="secondary">Submit Quiz</Button>
                ) : (
                    <Button onClick={handleNext}>Next</Button>
                )}
            </div>
        </Card>
    );
};

export default QuizTakingPage;
