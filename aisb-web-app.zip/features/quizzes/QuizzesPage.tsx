
import React, { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { quizzes } from '../../data/mockData';
import { Quiz } from '../../types';
import QuizTakingPage from './QuizTakingPage';
import QuizResultsPage from './QuizResultsPage';

const QuizCard: React.FC<{ quiz: Quiz, onStart: () => void }> = ({ quiz, onStart }) => {
  return (
    <Card>
      <h3 className="text-xl font-bold mb-2">{quiz.title}</h3>
      <p className="text-sm text-textSecondary mb-4">Course: {quiz.course}</p>
      <div className="flex justify-between items-center text-sm text-textPrimary mb-6">
        <span>{quiz.questions.length} Questions</span>
        <span>{quiz.timeLimit} min limit</span>
      </div>
      <Button 
        variant="secondary" 
        className="w-full" 
        onClick={onStart}
        disabled={quiz.questions.length === 0}
      >
        {quiz.questions.length > 0 ? 'Start Quiz' : 'Coming Soon'}
      </Button>
    </Card>
  );
};

type QuizState = 'list' | 'taking' | 'results';

const QuizzesPage: React.FC = () => {
    const [quizState, setQuizState] = useState<QuizState>('list');
    const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
    const [userAnswers, setUserAnswers] = useState<number[]>([]);

    const handleStartQuiz = (quiz: Quiz) => {
        setActiveQuiz(quiz);
        setUserAnswers(new Array(quiz.questions.length).fill(-1));
        setQuizState('taking');
    };

    const handleSubmitQuiz = (answers: number[]) => {
        setUserAnswers(answers);
        setQuizState('results');
    };

    const handleRetry = () => {
        if (activeQuiz) {
            handleStartQuiz(activeQuiz);
        }
    };

    const handleFinish = () => {
        setActiveQuiz(null);
        setQuizState('list');
    };

    if (quizState === 'taking' && activeQuiz) {
        return <QuizTakingPage quiz={activeQuiz} onSubmit={handleSubmitQuiz} />;
    }
    
    if (quizState === 'results' && activeQuiz) {
        return <QuizResultsPage quiz={activeQuiz} userAnswers={userAnswers} onRetry={handleRetry} onFinish={handleFinish} />;
    }

    return (
        <>
        <h1 className="text-3xl font-bold mb-6">Quizzes</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map(quiz => <QuizCard key={quiz.id} quiz={quiz} onStart={() => handleStartQuiz(quiz)} />)}
        </div>
        </>
    );
};

export default QuizzesPage;
