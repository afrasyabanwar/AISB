
import React from 'react';
import { Quiz } from '../../types';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';

interface QuizResultsPageProps {
  quiz: Quiz;
  userAnswers: number[];
  onRetry: () => void;
  onFinish: () => void;
}

const QuizResultsPage: React.FC<QuizResultsPageProps> = ({ quiz, userAnswers, onRetry, onFinish }) => {
    const score = quiz.questions.reduce((acc, question, index) => {
        return question.correctAnswerIndex === userAnswers[index] ? acc + 1 : acc;
    }, 0);
    const percentage = Math.round((score / quiz.questions.length) * 100);

    return (
        <div className="max-w-4xl mx-auto">
            <Card className="mb-6 text-center">
                <h1 className="text-3xl font-bold mb-2">Quiz Results</h1>
                <p className="text-lg text-textSecondary mb-4">{quiz.title}</p>
                <div className="flex justify-center items-baseline space-x-4">
                    <p className="text-5xl font-bold text-primary">{score} / {quiz.questions.length}</p>
                    <p className="text-3xl font-semibold text-secondary">({percentage}%)</p>
                </div>
            </Card>

            <h2 className="text-2xl font-bold mb-4">Review Your Answers</h2>
            <div className="space-y-4">
                {quiz.questions.map((question, index) => {
                    const userAnswerIndex = userAnswers[index];
                    const isCorrect = question.correctAnswerIndex === userAnswerIndex;
                    
                    return (
                        <Card key={index}>
                            <p className="font-semibold mb-3">{index + 1}. {question.questionText}</p>
                            <div className="space-y-2">
                                {question.options.map((option, optionIndex) => {
                                    let borderColor = 'border-gray-700';
                                    if (optionIndex === question.correctAnswerIndex) {
                                        borderColor = 'border-green-500';
                                    } else if (optionIndex === userAnswerIndex) {
                                        borderColor = 'border-red-500';
                                    }
                                    return (
                                        <div key={optionIndex} className={`p-3 rounded-md border-2 ${borderColor}`}>
                                            {option}
                                        </div>
                                    );
                                })}
                            </div>
                            <div className={`mt-3 p-3 rounded-md text-sm ${isCorrect ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                                <p className="font-bold mb-1">
                                    {isCorrect 
                                        ? `Correct!`
                                        : `Your answer: "${userAnswerIndex > -1 ? question.options[userAnswerIndex] : 'Not answered'}"`
                                    }
                                </p>
                                <p><span className="font-semibold">Explanation:</span> {question.explanation}</p>
                            </div>
                        </Card>
                    );
                })}
            </div>

            <div className="mt-8 flex justify-center space-x-4">
                <Button onClick={onRetry} variant="secondary">Retry Quiz</Button>
                <Button onClick={onFinish}>Back to Quizzes</Button>
            </div>
        </div>
    );
};

export default QuizResultsPage;
