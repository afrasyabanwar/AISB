import React from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

const SettingsPage: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      <Card className="max-w-2xl mx-auto">
        <h2 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Account Settings</h2>
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="font-medium">Change Password</h3>
                    <p className="text-sm text-textSecondary">Update your account password.</p>
                </div>
                <Button variant="secondary">Change</Button>
            </div>
             <div className="flex justify-between items-center">
                <div>
                    <h3 className="font-medium">Two-Factor Authentication</h3>
                    <p className="text-sm text-textSecondary">Add an extra layer of security to your account.</p>
                </div>
                <Button variant="secondary">Enable</Button>
            </div>
        </div>
        <h2 className="text-xl font-semibold mt-8 mb-4 border-b border-gray-700 pb-2">Notification Settings</h2>
         <div className="space-y-4">
            <div className="flex items-start">
                <input type="checkbox" id="email-notifications" className="mt-1 h-4 w-4 rounded border-gray-600 bg-gray-700 text-primary focus:ring-primary" defaultChecked />
                <div className="ml-3 text-sm">
                    <label htmlFor="email-notifications" className="font-medium text-textPrimary">Email Notifications</label>
                    <p className="text-textSecondary">Receive updates about courses and assignments via email.</p>
                </div>
            </div>
         </div>
      </Card>
    </>
  );
};

export default SettingsPage;
