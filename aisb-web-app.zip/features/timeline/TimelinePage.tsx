
import React, { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { timelinePosts } from '../../data/mockData';
import { TimelinePost } from '../../types';
import LikeIcon from '../../components/icons/LikeIcon';
import CommentIcon from '../../components/icons/CommentIcon';
import UpvoteIcon from '../../components/icons/UpvoteIcon';

const PostCard: React.FC<{ post: TimelinePost }> = ({ post: initialPost }) => {
    const [post, setPost] = useState(initialPost);
    const [liked, setLiked] = useState(false);

    const handleLike = () => {
        setPost(p => ({ ...p, likes: liked ? p.likes - 1 : p.likes + 1 }));
        setLiked(!liked);
    }
    
    return (
        <Card>
            <div className="flex items-start space-x-4">
                <img src={post.author.avatarUrl} alt={post.author.name} className="w-12 h-12 rounded-full" />
                <div className="flex-1">
                    <div className="flex items-baseline justify-between">
                        <p className="font-bold text-textPrimary">{post.author.name}</p>
                        <p className="text-xs text-textSecondary">{post.timestamp}</p>
                    </div>
                    <p className="mt-2 text-textPrimary whitespace-pre-wrap">{post.content}</p>
                </div>
            </div>
            <div className="mt-4 pt-2 border-t border-gray-700 flex justify-around items-center text-textSecondary">
                <button 
                    onClick={handleLike}
                    className={`flex items-center space-x-2 hover:text-secondary transition-colors ${liked ? 'text-secondary' : ''}`}
                    aria-pressed={liked}
                >
                    <LikeIcon className="w-5 h-5" />
                    <span>{post.likes} Likes</span>
                </button>
                 <button className="flex items-center space-x-2 hover:text-primary transition-colors">
                    <CommentIcon className="w-5 h-5" />
                    <span>{post.commentsCount} Comments</span>
                </button>
                 <button className="flex items-center space-x-2 hover:text-green-500 transition-colors">
                    <UpvoteIcon className="w-5 h-5" />
                    <span>{post.upvotes} Upvotes</span>
                </button>
            </div>
        </Card>
    );
}

const TimelinePage: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl font-bold mb-6">Timeline</h1>
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Create Post Card */}
        <Card>
            <h2 className="text-xl font-semibold mb-3">Create a Post</h2>
            <textarea
                className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
                rows={3}
                placeholder="Share something with the community..."
            />
            <div className="text-right mt-3">
                <Button>Post</Button>
            </div>
        </Card>
        
        {/* Posts Feed */}
        {timelinePosts.map(post => <PostCard key={post.id} post={post} />)}
      </div>
    </>
  );
};

export default TimelinePage;
