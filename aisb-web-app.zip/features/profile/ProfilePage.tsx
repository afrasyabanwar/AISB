import React from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const ProfilePage: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl font-bold mb-6">Your Profile</h1>
      <Card className="max-w-2xl mx-auto">
        <div className="flex items-center space-x-6 mb-8">
            <img src="https://i.pravatar.cc/100" alt="User Avatar" className="w-24 h-24 rounded-full" />
            <div>
                <h2 className="text-2xl font-bold">John Doe</h2>
                <p className="text-textSecondary">john.doe@example.com</p>
                <Button variant="secondary" className="mt-2 text-sm py-1 px-3">Change Photo</Button>
            </div>
        </div>
        
        <form className="space-y-4">
            <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-textSecondary">Full Name</label>
                <Input id="fullName" type="text" defaultValue="John Doe" />
            </div>
            <div>
                <label htmlFor="bio" className="block text-sm font-medium text-textSecondary">Bio</label>
                <textarea 
                    id="bio"
                    rows={3}
                    className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
                    placeholder="Tell us a little about yourself"
                ></textarea>
            </div>
             <div className="pt-4">
                <Button type="submit">Save Changes</Button>
            </div>
        </form>
      </Card>
    </>
  );
};

export default ProfilePage;
