
import React from 'react';
import Card from '../../components/ui/Card';
import { leaderboardData } from '../../data/mockData';

interface LeaderboardEntry {
  rank: number;
  name: string;
  score: number;
  avatarUrl: string;
}

const LeaderboardRow: React.FC<{ entry: LeaderboardEntry, isCurrentUser?: boolean }> = ({ entry, isCurrentUser = false }) => {
    const rankColors: { [key: number]: string } = {
        1: 'bg-yellow-500 text-yellow-900',
        2: 'bg-gray-400 text-gray-900',
        3: 'bg-yellow-700 text-yellow-100',
    };

    const getRankIndicator = () => {
        if (entry.rank <= 3) {
            return (
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${rankColors[entry.rank]}`}>
                    {entry.rank}
                </div>
            )
        }
        return <div className="w-8 h-8 flex items-center justify-center font-semibold text-textSecondary">{entry.rank}</div>;
    }

    return (
        <div className={`flex items-center p-3 rounded-lg ${isCurrentUser ? 'bg-primary/20 border border-primary' : ''}`}>
            <div className="w-12">{getRankIndicator()}</div>
            <div className="flex items-center flex-1 ml-4">
                <img src={entry.avatarUrl} alt={entry.name} className="w-10 h-10 rounded-full mr-4" />
                <span className="font-medium text-textPrimary">{entry.name}</span>
            </div>
            <div className="font-bold text-secondary text-lg">{entry.score} pts</div>
        </div>
    );
};

const LeaderboardPage: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl font-bold mb-6">Leaderboard</h1>
      <Card className="max-w-3xl mx-auto">
        <div className="space-y-2">
            {leaderboardData.map(entry => (
                <LeaderboardRow key={entry.rank} entry={entry} isCurrentUser={entry.name === 'John Doe'}/>
            ))}
        </div>
      </Card>
    </>
  );
};

export default LeaderboardPage;
