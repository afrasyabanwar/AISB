
import React, { useState } from 'react';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import SendIcon from '../../components/icons/SendIcon';
import { chatContacts, chatMessages } from '../../data/mockData';

interface Message {
  id: string;
  text: string;
  sender: 'me' | 'other';
  timestamp: string;
}

interface Contact {
  id: string;
  name: string;
  avatarUrl: string;
  lastMessage: string;
}

const ChatPage: React.FC = () => {
  const [selectedContact, setSelectedContact] = useState<Contact | null>(chatContacts[0]);
  const [messages, setMessages] = useState<Message[]>(chatMessages[chatContacts[0].id]);

  const handleSelectContact = (contact: Contact) => {
    setSelectedContact(contact);
    setMessages(chatMessages[contact.id] || []);
  };

  return (
    <>
      <h1 className="text-3xl font-bold mb-6">Chat</h1>
      <Card className="h-[75vh] flex p-0 overflow-hidden">
        {/* Contacts Panel */}
        <div
          className={`w-full md:w-1/3 border-r border-gray-700 flex flex-col transition-all duration-300 ${
            selectedContact ? 'hidden md:flex' : 'flex'
          }`}
        >
          <div className="p-4 border-b border-gray-700">
            <Input type="search" placeholder="Search contacts..." />
          </div>
          <div className="flex-1 overflow-y-auto">
            {chatContacts.map(contact => (
              <div
                key={contact.id}
                onClick={() => handleSelectContact(contact)}
                className={`flex items-center p-3 cursor-pointer hover:bg-gray-700 ${selectedContact?.id === contact.id ? 'bg-primary/30' : ''}`}
              >
                <img src={contact.avatarUrl} alt={contact.name} className="w-12 h-12 rounded-full mr-3" />
                <div className="flex-1 truncate">
                  <p className="font-semibold text-textPrimary">{contact.name}</p>
                  <p className="text-sm text-textSecondary truncate">{contact.lastMessage}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Window */}
        <div
          className={`w-full md:w-2/3 flex flex-col transition-all duration-300 ${
            selectedContact ? 'flex' : 'hidden md:flex'
          }`}
        >
          {selectedContact ? (
            <>
              <div className="p-4 border-b border-gray-700 flex items-center">
                 <button onClick={() => setSelectedContact(null)} className="md:hidden mr-3 text-textPrimary" aria-label="Back to contacts">
                     &larr;
                 </button>
                <img src={selectedContact.avatarUrl} alt={selectedContact.name} className="w-10 h-10 rounded-full mr-3" />
                <h2 className="text-xl font-bold">{selectedContact.name}</h2>
              </div>
              <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                {messages.map(msg => (
                  <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-md px-4 py-2 rounded-xl ${msg.sender === 'me' ? 'bg-primary text-white' : 'bg-gray-600'}`}>
                      <p>{msg.text}</p>
                      <p className="text-xs opacity-70 mt-1 text-right">{msg.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-4 border-t border-gray-700">
                <form className="flex items-center space-x-2">
                  <Input type="text" placeholder="Type a message..." className="flex-1" />
                  <Button type="submit" className="p-3"><SendIcon className="w-5 h-5" /></Button>
                </form>
              </div>
            </>
          ) : (
            <div className="hidden md:flex items-center justify-center h-full">
              <p className="text-textSecondary">Select a contact to start chatting.</p>
            </div>
          )}
        </div>
      </Card>
    </>
  );
};

export default ChatPage;
