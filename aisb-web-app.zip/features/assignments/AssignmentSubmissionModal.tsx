
import React, { useState } from 'react';
import Modal from '../../components/ui/Modal';
import { StudentAssignment } from '../../types';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';

interface AssignmentSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  assignment: StudentAssignment;
  onSubmit: (assignmentId: string, submission: { text?: string, fileName?: string }) => void;
}

const AssignmentSubmissionModal: React.FC<AssignmentSubmissionModalProps> = ({ isOpen, onClose, assignment, onSubmit }) => {
    const [submissionText, setSubmissionText] = useState('');
    const [submissionFile, setSubmissionFile] = useState<File | null>(null);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(assignment.id, { text: submissionText, fileName: submissionFile?.name });
    };
    
    const isSubmittedOrGraded = assignment.status === 'Submitted' || assignment.status === 'Graded';

    const renderSubmissionForm = () => (
        <form onSubmit={handleSubmit} className="space-y-4">
             <div>
                <label htmlFor="submissionText" className="block text-sm font-medium text-textSecondary mb-1">Comments or Text Submission</label>
                <textarea
                    id="submissionText"
                    rows={4}
                    value={submissionText}
                    onChange={(e) => setSubmissionText(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary"
                    placeholder="Add any comments for your instructor..."
                />
            </div>
            <div>
                 <label htmlFor="fileUpload" className="block text-sm font-medium text-textSecondary mb-1">Upload File</label>
                 <Input
                    id="fileUpload"
                    type="file"
                    onChange={(e) => e.target.files && setSubmissionFile(e.target.files[0])}
                    className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-primary/80"
                 />
            </div>
            <div className="pt-4 flex justify-end space-x-2">
                <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
                <Button type="submit">Submit Assignment</Button>
            </div>
        </form>
    );

    const renderSubmissionDetails = () => (
        <div className="space-y-4">
            <div>
                <h4 className="font-semibold text-textSecondary">Your Submission:</h4>
                <p className="mt-1 p-3 bg-gray-900/50 rounded-md whitespace-pre-wrap">{assignment.submission?.text || 'No comments provided.'}</p>
                {assignment.submission?.fileName && (
                    <p className="mt-2 text-sm">File: <span className="font-medium text-secondary">{assignment.submission.fileName}</span></p>
                )}
            </div>

            {assignment.status === 'Graded' && (
                <div>
                     <h4 className="font-semibold text-textSecondary">Feedback from Instructor:</h4>
                     <div className="mt-1 p-3 bg-green-500/10 rounded-md border border-green-500/50">
                        <p className="text-2xl font-bold mb-2">Grade: {assignment.grade}</p>
                        <p>{assignment.feedback}</p>
                     </div>
                </div>
            )}
             <div className="pt-4 flex justify-end">
                <Button onClick={onClose}>Close</Button>
            </div>
        </div>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={assignment.title}>
            <div className="space-y-4">
                <div>
                    <p className="text-sm text-textSecondary">Course: {assignment.courseName}</p>
                    <p className="text-sm text-textSecondary">Due Date: {new Date(assignment.dueDate).toLocaleDateString()}</p>
                </div>
                <p className="text-textPrimary pt-2 border-t border-gray-700">{assignment.description}</p>
            </div>

            <div className="mt-6 pt-6 border-t border-gray-700">
                <h3 className="text-lg font-bold mb-3">{isSubmittedOrGraded ? 'Submission Details' : 'Submit Your Work'}</h3>
                {isSubmittedOrGraded ? renderSubmissionDetails() : renderSubmissionForm()}
            </div>
        </Modal>
    );
};

export default AssignmentSubmissionModal;
