
import React, { useState } from 'react';
import Card from '../../components/ui/Card';
import { studentAssignments as initialAssignments } from '../../data/mockData';
import { StudentAssignment } from '../../types';
import Button from '../../components/ui/Button';
import AssignmentSubmissionModal from './AssignmentSubmissionModal';

const AssignmentCard: React.FC<{ assignment: StudentAssignment, onSelect: () => void }> = ({ assignment, onSelect }) => {
    const statusStyles: { [key: string]: string } = {
        'Not Submitted': 'border-yellow-500 text-yellow-300',
        'Submitted': 'border-blue-500 text-blue-300',
        'Graded': 'border-green-500 text-green-300',
    };

    return (
        <Card className="flex flex-col">
            <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold mb-1">{assignment.title}</h3>
                <span className={`text-xs font-semibold px-2 py-1 border rounded-full ${statusStyles[assignment.status]}`}>
                    {assignment.status}
                </span>
            </div>
            <p className="text-sm text-textSecondary mb-4">Course: {assignment.courseName}</p>
            <p className="text-sm text-textSecondary flex-grow">Due: {new Date(assignment.dueDate).toLocaleDateString()}</p>
            {assignment.status === 'Graded' && (
                 <p className="text-2xl font-bold text-secondary mt-2">Grade: {assignment.grade}</p>
            )}
            <Button variant="secondary" className="w-full mt-4" onClick={onSelect}>
                {assignment.status === 'Not Submitted' ? 'View & Submit' : 'View Details'}
            </Button>
        </Card>
    );
};


const AssignmentsPage: React.FC = () => {
    const [assignments, setAssignments] = useState<StudentAssignment[]>(initialAssignments);
    const [selectedAssignment, setSelectedAssignment] = useState<StudentAssignment | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleSelectAssignment = (assignment: StudentAssignment) => {
        setSelectedAssignment(assignment);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedAssignment(null);
    };

    const handleSubmitAssignment = (assignmentId: string, submission: { text?: string, fileName?: string }) => {
        setAssignments(prev => 
            prev.map(a => 
                a.id === assignmentId 
                ? { ...a, status: 'Submitted', submission } 
                : a
            )
        );
        handleCloseModal();
    };

    return (
        <>
            <h1 className="text-3xl font-bold mb-6">Assignments</h1>
            {assignments.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {assignments.map(a => (
                        <AssignmentCard key={a.id} assignment={a} onSelect={() => handleSelectAssignment(a)} />
                    ))}
                </div>
            ) : (
                <Card>
                    <div className="text-center py-12">
                        <h2 className="text-xl font-semibold text-textPrimary">No assignments due soon.</h2>
                        <p className="text-textSecondary mt-2">Check back later or view assignments within each course.</p>
                    </div>
                </Card>
            )}

            {selectedAssignment && (
                <AssignmentSubmissionModal
                    isOpen={isModalOpen}
                    onClose={handleCloseModal}
                    assignment={selectedAssignment}
                    onSubmit={handleSubmitAssignment}
                />
            )}
        </>
    );
};

export default AssignmentsPage;
