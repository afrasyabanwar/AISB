
import React, { useState } from 'react';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import { User } from '../../types';
import { users } from '../../data/mockData';

interface AuthPageProps {
  onLogin: (user: User) => void;
}

type AuthMode = 'login' | 'signupStudent' | 'signupInstructor';

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [error, setError] = useState<string | null>(null);
  
  // Form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [expertise, setExpertise] = useState('');

  const isLogin = authMode === 'login';
  const isStudentSignup = authMode === 'signupStudent';
  const isInstructorSignup = authMode === 'signupInstructor';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isLogin) {
      console.log('Logging in with:', { email, password });
      const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

      if (user) {
        // In a real app, you'd verify the password here.
        onLogin(user);
      } else {
        setError("Invalid email or password. Please try again.");
      }
    } else { // Handle both signups
      // For demo, create a new user object.
      // In a real app, this would come from a backend response.
      const newUser: User = {
        id: `user-${Date.now()}`,
        name: name,
        email: email,
        avatarUrl: `https://i.pravatar.cc/40?u=${email}`,
        role: isStudentSignup ? 'Student' : 'Instructor',
      };
      onLogin(newUser);
    }
  };

  const handleGoogleSignIn = () => {
    setError(null);
    // In a real app, this would trigger the Google OAuth flow.
    // Here, we simulate it by prompting for an email.
    const userEmail = window.prompt("To simulate Google Sign-In, please enter your email address:");

    if (!userEmail) {
      return; // User cancelled the prompt
    }

    const existingUser = users.find(u => u.email.toLowerCase() === userEmail.toLowerCase());

    if (existingUser) {
      // If user exists, log them in
      onLogin(existingUser);
    } else {
      // If user doesn't exist, simulate the sign-up flow
      const userName = window.prompt(`Welcome! We couldn't find an account for ${userEmail}. Please enter your full name to create one:`);
      
      if (!userName) {
        return; // User cancelled the name prompt
      }

      const newUser: User = {
        id: `user-${Date.now()}`,
        name: userName,
        email: userEmail,
        avatarUrl: `https://i.pravatar.cc/40?u=${userEmail}`,
        role: 'Student', // New Google sign-ups default to Student
      };
      onLogin(newUser);
    }
  };
  
  const renderFormFields = () => {
    if (isLogin) {
      return (
        <>
          <Input type="email" placeholder="Email Address" required value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder="Password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </>
      );
    }
    
    // Common fields for both signup forms
    const commonSignupFields = (
      <>
        <Input type="text" placeholder="Full Name" required value={name} onChange={(e) => setName(e.target.value)} />
        <Input type="email" placeholder="Email Address" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <Input type="tel" placeholder="Phone Number" required value={phone} onChange={(e) => setPhone(e.target.value)} />
        <Input type="password" placeholder="Password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      </>
    );

    if (isStudentSignup) {
      return (
        <>
          {commonSignupFields}
          <div>
            <label htmlFor="class-select" className="text-sm text-textSecondary">Select your class</label>
            <select id="class-select" className="w-full mt-1 px-3 py-2 bg-background border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-textPrimary">
              <option>Generative Class</option>
              <option>Agentic Class</option>
            </select>
          </div>
        </>
      );
    }

    if (isInstructorSignup) {
        return (
            <>
                {commonSignupFields}
                <Input type="text" placeholder="Subject Matter Expertise (e.g., React, AI, Design)" required value={expertise} onChange={(e) => setExpertise(e.target.value)} />
            </>
        )
    }

    return null;
  };

  return (
    <div className="flex items-center justify-center min-h-screen">
      <Card className="w-full max-w-md">
        <h1 className="text-3xl font-bold text-center mb-2">Welcome to AISB</h1>
        <p className="text-center text-textSecondary mb-6">Your AI-Powered Learning Companion</p>
        <div className="flex justify-center mb-6 border-b border-gray-700">
          <button 
            onClick={() => { setAuthMode('login'); setError(null); }}
            className={`px-4 py-2 text-lg font-semibold transition-colors ${isLogin ? 'text-primary border-b-2 border-primary' : 'text-textSecondary'}`}
            aria-pressed={isLogin}
          >
            Login
          </button>
          <button 
            onClick={() => { setAuthMode('signupStudent'); setError(null); }}
            className={`px-4 py-2 text-lg font-semibold transition-colors ${isStudentSignup ? 'text-primary border-b-2 border-primary' : 'text-textSecondary'}`}
            aria-pressed={isStudentSignup}
          >
            Sign Up
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {renderFormFields()}

          {error && (
            <p className="text-red-500 text-sm text-center my-2">{error}</p>
          )}

          <Button type="submit" className="w-full">
            {isLogin ? 'Login' : 'Create Account'}
          </Button>
          
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-600" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-surface px-2 text-textSecondary">Or</span>
            </div>
          </div>
          
          <Button type="button" variant="secondary" className="w-full" onClick={handleGoogleSignIn}>
            Sign In with Google
          </Button>

          {!isInstructorSignup && (
             <div className="text-center mt-4">
                <button type="button" onClick={() => { setAuthMode('signupInstructor'); setError(null); }} className="text-sm text-primary hover:underline">
                    Sign Up as an Instructor
                </button>
             </div>
          )}
        </form>
      </Card>
    </div>
  );
};

export default AuthPage;
