
import { useState, useEffect, useCallback, useRef } from 'react';
import { AssistantStatus, AssistantMessage } from '../types';
import { getAisuResponse } from '../services/geminiService';
import eventBus from '../services/eventBus';

const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

const commands: { [key: string]: string[] } = {
    'Dashboard': ['go to dashboard', 'open dashboard', 'show dashboard'],
    'Courses': ['go to courses', 'open courses', 'show me my courses'],
    'Quizzes': ['go to quizzes', 'open quizzes', 'show quizzes'],
    'Assignments': ['go to assignments', 'open assignments', 'show assignments', 'show me my assignments'],
    'Leaderboard': ['go to leaderboard', 'open leaderboard', 'show leaderboard'],
    'Chat': ['go to chat', 'open chat'],
    'Timeline': ['go to timeline', 'open timeline'],
};

const handleCommand = (transcript: string): boolean => {
    const lowerTranscript = transcript.toLowerCase();
    for (const page in commands) {
        if (commands[page].some(phrase => lowerTranscript.includes(phrase))) {
            eventBus.dispatch('navigate', page);
            return true; // Command was handled
        }
    }
    return false; // No command found
};

export const useVoiceAssistant = () => {
    const [status, setStatus] = useState<AssistantStatus>('idle');
    const [messages, setMessages] = useState<AssistantMessage[]>([]);
    const [isMuted, setIsMuted] = useState<boolean>(false);
    const recognitionRef = useRef<any>(null);

    const statusRef = useRef(status);
    useEffect(() => {
        statusRef.current = status;
    }, [status]);
    
    const isMutedRef = useRef(isMuted);
    useEffect(() => {
        isMutedRef.current = isMuted;
    }, [isMuted]);

    const isSupported = !!SpeechRecognition;

    const submitPrompt = useCallback(async (prompt: string) => {
        if (!prompt) return;
        
        // Don't show command in chat
        const wasHandledAsCommand = handleCommand(prompt);
        if (wasHandledAsCommand) {
             setStatus('idle');
             return;
        }

        setMessages(prev => [...prev, { speaker: 'user', text: prompt }]);
        setStatus('processing');

        try {
            const responseText = await getAisuResponse(prompt);
            setMessages(prev => [...prev, { speaker: 'aisu', text: responseText }]);
            
            if (!isMutedRef.current) {
                setStatus('speaking');
                const utterance = new SpeechSynthesisUtterance(responseText);
                // Make voice cartoonish
                utterance.pitch = 1.5;
                utterance.rate = 1.2;
                utterance.onend = () => setStatus('idle');
                utterance.onerror = (e) => {
                    console.error("Speech synthesis error:", e);
                    setStatus('idle');
                };
                speechSynthesis.speak(utterance);
            } else {
                setStatus('idle');
            }
        } catch (error) {
            console.error("Error processing prompt:", error);
            const errorMessage = "I encountered an error. Please try again.";
            setMessages(prev => [...prev, { speaker: 'aisu', text: errorMessage }]);
            setStatus('idle');
        }
    }, []);

    useEffect(() => {
        if (!isSupported) {
            console.warn("Speech Recognition API is not supported in this browser.");
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.lang = 'en-US';
        recognition.interimResults = false;

        recognition.onstart = () => {
            setStatus('listening');
        };

        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            submitPrompt(transcript);
        };

        recognition.onerror = (event: any) => {
            console.error("Speech recognition error:", event.error);
            setStatus('idle');
        };
        
        recognition.onend = () => {
            // If recognition ends and we're still 'listening', it means no speech was detected.
            // Other state transitions are handled by their respective async flows.
            if (statusRef.current === 'listening') {
               setStatus('idle');
            }
        };

        recognitionRef.current = recognition;

        return () => {
            speechSynthesis.cancel();
            recognitionRef.current?.abort();
        };
    }, [isSupported, submitPrompt]);


    const startListening = useCallback(() => {
        if (status === 'idle' && recognitionRef.current) {
            try {
                recognitionRef.current.start();
            } catch(e) {
                console.error("Could not start recognition", e);
                setStatus('idle');
            }
        }
    }, [status]);

    const stopListening = useCallback(() => {
        if (recognitionRef.current) {
            recognitionRef.current.stop();
        }
        setStatus('idle');
    }, []);

    const clearMessages = useCallback(() => {
        setMessages([]);
    }, []);

    const toggleMute = useCallback(() => {
        setIsMuted(prev => !prev);
    }, []);

    return { status, messages, startListening, stopListening, isSupported, clearMessages, submitPrompt, isMuted, toggleMute };
};
