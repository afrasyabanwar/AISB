import { GoogleGenAI } from "@google/genai";

// Ensure API key is available in the environment
const apiKey = process.env.API_KEY;
if (!apiKey) {
    throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey });

const systemInstruction = `You are AISU, a friendly and helpful AI assistant for the AISB Web App, a learning platform. Your role is to assist students and instructors.
- Be encouraging and supportive.
- Answer questions about courses, assignments, and general knowledge concisely.
- If asked to do something you can't (e.g., "submit my assignment"), explain that you can't perform actions but can guide the user on how to do it.
- Keep responses brief and to the point.
- Do not provide answers to graded quizzes or assignments directly. Instead, offer hints or explain concepts.
- Do not use any emojis in your responses.
- Example queries you can handle: "What are my courses?", "Explain the concept of photosynthesis", "Who was Albert Einstein?".`;

export async function getAisuResponse(prompt: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
            },
        });
        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        return "I'm sorry, I'm having a little trouble connecting right now. Please try again in a moment.";
    }
}