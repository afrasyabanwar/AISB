
interface EventBus {
  on(event: string, callback: (data?: any) => void): void;
  dispatch(event: string, data?: any): void;
  remove(event: string, callback: (data?: any) => void): void;
}

const eventBus: EventBus = {
  on(event, callback) {
    const listener = (e: Event) => {
        const customEvent = e as CustomEvent;
        callback(customEvent.detail);
    };
    document.addEventListener(event, listener);
  },
  dispatch(event, data) {
    document.dispatchEvent(new CustomEvent(event, { detail: data }));
  },
  remove(event, callback) {
     const listener = (e: Event) => {
        const customEvent = e as CustomEvent;
        callback(customEvent.detail);
    };
    document.removeEventListener(event, listener);
  },
};

export default eventBus;
