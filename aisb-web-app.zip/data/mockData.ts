
import { Course, TimelinePost, User, Assignment, Quiz, StudentAssignment } from '../types';

export const courses: Course[] = [
    { 
        id: '1', 
        title: 'Introduction to React', 
        description: 'Learn the fundamentals of React and build modern web applications.', 
        instructor: 'John Doe', 
        progress: 75,
        modules: [
            { id: 'm1-1', title: 'Module 1: Getting Started', status: 'Completed' },
            { id: 'm1-2', title: 'Module 2: Components and Props', status: 'Completed' },
            { id: 'm1-3', title: 'Module 3: State and Lifecycle', status: 'In Progress' },
            { id: 'm1-4', title: 'Module 4: Handling Events', status: 'Not Started' },
        ]
    },
    { 
        id: '2', 
        title: 'Advanced Tailwind CSS', 
        description: 'Master utility-first CSS and create beautiful, responsive designs.', 
        instructor: 'Jane Smith', 
        progress: 40,
        modules: [
            { id: 'm2-1', title: 'Module 1: Utility-First Fundamentals', status: 'Completed' },
            { id: 'm2-2', title: 'Module 2: Responsive Design', status: 'In Progress' },
            { id: 'm2-3', title: 'Module 3: Customization', status: 'Not Started' },
        ]
    },
    { 
        id: '3', 
        title: 'TypeScript for Professionals', 
        description: 'Deep dive into TypeScript for large-scale applications.', 
        instructor: 'Sam Wilson', 
        progress: 95,
        modules: [
            { id: 'm3-1', title: 'Module 1: Basic Types', status: 'Completed' },
            { id: 'm3-2', title: 'Module 2: Interfaces and Classes', status: 'Completed' },
            { id: 'm3-3', title: 'Module 3: Advanced Types', status: 'Completed' },
            { id: 'm3-4', title: 'Module 4: Generics', status: 'Completed' },
        ]
    },
    { id: '4', title: 'Node.js Backend Development', description: 'Build scalable and efficient server-side applications.', instructor: 'Alex Johnson', progress: 15 },
    { id: '5', title: 'Mastering Prisma and PostgreSQL', description: 'A comprehensive guide to database management with Prisma ORM.', instructor: 'Maria Garcia', progress: 0 },
    { id: '6', title: 'UI/UX Design Principles', description: 'Learn the core principles of user-centric design.', instructor: 'Chris Lee', progress: 100 },
];

export const quizzes: Quiz[] = [
  { 
    id: '1', 
    title: 'React Basics Quiz', 
    course: 'Introduction to React', 
    timeLimit: 1, // 1 minute for demo
    questions: [
      {
        questionText: 'What is JSX?',
        options: ['A JavaScript syntax extension', 'A templating engine', 'A CSS preprocessor', 'A database query language'],
        correctAnswerIndex: 0,
        explanation: 'JSX stands for JavaScript XML. It is a syntax extension to JavaScript and is used with React to describe what the UI should look like.'
      },
      {
        questionText: 'Which method in a React class component is called after the component is rendered for the first time?',
        options: ['componentDidMount', 'componentWillMount', 'componentDidUpdate', 'render'],
        correctAnswerIndex: 0,
        explanation: '`componentDidMount()` is invoked immediately after a component is mounted (inserted into the tree). It is a good place to do network requests.'
      },
      {
        questionText: 'What is the purpose of `useState` in a functional component?',
        options: ['To manage component side effects', 'To add stateful logic to the component', 'To fetch data from an API', 'To declare a component'],
        correctAnswerIndex: 1,
        explanation: '`useState` is a Hook that lets you add React state to function components. It returns a pair: the current state value and a function that lets you update it.'
      }
    ] 
  },
  { 
    id: '2', 
    title: 'CSS Flexbox Challenge', 
    course: 'Advanced Tailwind CSS', 
    timeLimit: 5,
    questions: [
      {
        questionText: 'Which property is used to align items along the main axis?',
        options: ['align-items', 'justify-content', 'flex-direction', 'align-content'],
        correctAnswerIndex: 1,
        explanation: '`justify-content` is used to align flex items along the main axis of the current line of the flex container.'
      }
    ]
  },
  { id: '3', title: 'TypeScript Fundamentals', course: 'TypeScript for Professionals', timeLimit: 20, questions: [] },
  { id: '4', title: 'Node.js Event Loop', course: 'Node.js Backend Development', timeLimit: 10, questions: [] },
];

export const leaderboardData = [
  { rank: 1, name: 'Alice Johnson', score: 1540, avatarUrl: 'https://i.pravatar.cc/40?u=1' },
  { rank: 2, name: 'Bob Williams', score: 1490, avatarUrl: 'https://i.pravatar.cc/40?u=2' },
  { rank: 3, name: 'Charlie Brown', score: 1450, avatarUrl: 'https://i.pravatar.cc/40?u=3' },
  { rank: 4, name: 'John Doe', score: 1380, avatarUrl: 'https://i.pravatar.cc/40' },
  { rank: 5, name: 'Diana Miller', score: 1320, avatarUrl: 'https://i.pravatar.cc/40?u=5' },
  { rank: 6, name: 'Eve Davis', score: 1250, avatarUrl: 'https://i.pravatar.cc/40?u=6' },
  { rank: 7, name: 'Frank Garcia', score: 1190, avatarUrl: 'https://i.pravatar.cc/40?u=7' },
];

export const timelinePosts: TimelinePost[] = [
    {
        id: 'post1',
        author: { name: 'Alice Johnson', avatarUrl: 'https://i.pravatar.cc/40?u=1' },
        content: 'Just generated this amazing piece of art using an AI image generator! The prompt was "a futuristic city skyline at dusk, in the style of synthwave". So happy with how it turned out. #AIArt #GenerativeAI',
        timestamp: '2 hours ago',
        likes: 28,
        commentsCount: 7,
        upvotes: 15,
    },
    {
        id: 'post2',
        author: { name: 'John Doe', avatarUrl: 'https://i.pravatar.cc/40' },
        content: 'I\'m really struggling with the "State and Lifecycle" module in the React course. Can anyone share some resources that helped them understand it better?',
        timestamp: '5 hours ago',
        likes: 12,
        commentsCount: 9,
        upvotes: 4,
    },
    {
        id: 'post3',
        author: { name: 'Jane Smith', avatarUrl: 'https://i.pravatar.cc/40?u=4' },
        content: 'Quick tip for anyone working with Tailwind CSS: use the `@apply` directive sparingly. It can be useful, but overusing it can lead to code that\'s hard to maintain. Utility-first is the way to go!',
        timestamp: '1 day ago',
        likes: 45,
        commentsCount: 12,
        upvotes: 22,
    },
];

export const chatContacts = [
    { id: 'contact1', name: 'Jane Smith', avatarUrl: 'https://i.pravatar.cc/40?u=4', lastMessage: 'Sure, I can help with that!' },
    { id: 'contact2', name: 'Sam Wilson', avatarUrl: 'https://i.pravatar.cc/40?u=3', lastMessage: 'See you in the lecture tomorrow.' },
    { id: 'contact3', name: 'Alice Johnson', avatarUrl: 'https://i.pravatar.cc/40?u=1', lastMessage: 'That\'s a great idea for the project.' },
    { id: 'contact4', name: 'Bob Williams', avatarUrl: 'https://i.pravatar.cc/40?u=2', lastMessage: 'Did you finish the assignment?' },
];

export const chatMessages: { [key: string]: any[] } = {
    'contact1': [
        { id: 'msg1-1', text: 'Hey Jane, I had a question about the Tailwind CSS project.', sender: 'me', timestamp: '10:30 AM' },
        { id: 'msg1-2', text: 'Hey! Sure, what\'s up?', sender: 'other', timestamp: '10:31 AM' },
        { id: 'msg1-3', text: 'I\'m having trouble making the mobile navigation responsive. It breaks on smaller screens.', sender: 'me', timestamp: '10:32 AM' },
        { id: 'msg1-4', text: 'Ah, a classic issue. Have you tried using the `sm:` prefix and setting the default to be mobile-first? Send me your code snippet.', sender: 'other', timestamp: '10:33 AM' },
        { id: 'msg1-5', text: 'Sure, I can help with that!', sender: 'me', timestamp: '10:35 AM' },
    ],
    'contact2': [
        { id: 'msg2-1', text: 'Hi Sam, just wanted to confirm the study group meeting time.', sender: 'me', timestamp: 'Yesterday' },
        { id: 'msg2-2', text: 'Yep, 4 PM at the library. See you in the lecture tomorrow.', sender: 'other', timestamp: 'Yesterday' },
    ],
    'contact3': [
        { id: 'msg3-1', text: 'That AI art you posted was amazing!', sender: 'me', timestamp: '3 hours ago' },
        { id: 'msg3-2', text: 'Thanks so much! I\'m glad you liked it. That\'s a great idea for the project.', sender: 'other', timestamp: '3 hours ago' },
    ],
     'contact4': [
        { id: 'msg4-1', text: 'Did you finish the assignment?', sender: 'other', timestamp: '5 hours ago' },
    ],
};

export const users: User[] = [
    { id: 'user-1', name: 'John Doe', email: 'john.doe@example.com', avatarUrl: 'https://i.pravatar.cc/40', role: 'Student' },
    { id: 'user-2', name: 'Alice Johnson', email: 'alice.j@example.com', avatarUrl: 'https://i.pravatar.cc/40?u=1', role: 'Student' },
    { id: 'user-3', name: 'Jane Smith', email: 'jane.smith@instructor.com', avatarUrl: 'https://i.pravatar.cc/40?u=4', role: 'Instructor' },
    { id: 'user-4', name: 'Sam Wilson', email: 'sam.wilson@instructor.com', avatarUrl: 'https://i.pravatar.cc/40?u=3', role: 'Instructor' },
    { id: 'user-5', name: 'Admin User', email: 'admin@aisb.com', avatarUrl: 'https://i.pravatar.cc/40?u=admin', role: 'Admin' },
];

// This is the admin-facing assignment list
export const assignments: Assignment[] = [
    { id: 'assign-1', title: 'React Component Design', courseId: '1', dueDate: '2024-08-15', status: 'Published' },
    { id: 'assign-2', title: 'Tailwind Responsive Grid', courseId: '2', dueDate: '2024-08-20', status: 'Published' },
    { id: 'assign-3', title: 'TypeScript Advanced Types', courseId: '3', dueDate: '2024-09-01', status: 'Draft' },
    { id: 'assign-4', title: 'Final Project Proposal', courseId: '1', dueDate: '2024-09-10', status: 'Archived' },
];

// This is the student-facing assignment list
export const studentAssignments: StudentAssignment[] = [
    {
        id: 'assign-1',
        title: 'React Component Design',
        courseName: 'Introduction to React',
        dueDate: '2024-08-15',
        description: 'Design and build a reusable Card component in React. The component should accept props for title, content, and an optional image. Style it using Tailwind CSS.',
        status: 'Not Submitted',
    },
    {
        id: 'assign-2',
        title: 'Tailwind Responsive Grid',
        courseName: 'Advanced Tailwind CSS',
        dueDate: '2024-08-20',
        description: 'Create a responsive image gallery using Tailwind CSS grid and flexbox utilities. The gallery should look good on mobile, tablet, and desktop screens.',
        status: 'Submitted',
        submission: {
            text: "Here is my submission. I found the responsive breakpoints a bit tricky but I think I got it.",
            fileName: "tailwind-gallery.zip"
        }
    },
    {
        id: 'assign-5', // Made-up ID for a graded example
        title: 'UI/UX Case Study',
        courseName: 'UI/UX Design Principles',
        dueDate: '2024-08-10',
        description: 'Analyze the user flow of a popular application and suggest three improvements. Justify your suggestions with design principles.',
        status: 'Graded',
        grade: 'A-',
        feedback: 'Excellent analysis! Your suggestions are well-reasoned and align with established UX principles. For even greater impact, consider including wireframes for your proposed changes.',
        submission: {
            text: "Please find my case study attached.",
            fileName: "CaseStudy-Analysis.pdf"
        }
    }
];
